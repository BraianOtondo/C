#include <stdlib.h>
#include <stdio.h>
#include "ListaEnC.h"
#ifndef COLA
#define COLA

typedef ListaEnc Cola;


void encolar(Cola* c, Persona p);
void desencolar(Cola* c, Persona* p);
void peek(Cola* c, Persona* p);





#endif // COLA
